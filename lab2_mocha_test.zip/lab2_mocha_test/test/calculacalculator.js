var expect = require("chai").expect;
var calculator = require("../app/calculator");

describe("Calculator App", () =>{
    describe("Addition Example: ", () => {
        it("PASS: 5 + 2 returns 7", () =>{
            expect(calculator.add(5, 2));
        });
        it("FAIL: 5 + 2 returns 10", () => {
            expect(10).to.equal(calculator.add(5,2));
        });
    });
    describe("Subtraction Example:", () => {
        it("PASS: 5 - 2 returns 3", () =>{
            expect(calculator.sub(5, 2));
        });
        it("FAIL: 5 - 2 returns 5", () => {
            expect(5).to.equal(calculator.sub(5,2));
        });
    });
    describe("Multiplication Example:", () => {
        it("PASS: 5 * 2 returns 10", () =>{
            expect(calculator.mul(5, 2));
        });
        it("FAIL: 5 * 2 returns 12", () => {
            expect(12).to.equal(calculator.mul(5,2));
        });
    });
    describe("Division Example:", () => {
        it("PASS: 10 / 2 returns 5", () =>{
            expect(calculator.div(10, 2));
        });
        it("FAIL: 10 / 2 returns 3", () => {
            expect(3).to.equal(calculator.div(10,2));
        });
    });
});